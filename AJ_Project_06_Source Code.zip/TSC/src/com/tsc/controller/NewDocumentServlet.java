package com.tsc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tsc.bo.RegisterBO;
import com.tsc.model.Document;

@WebServlet("/NewDocumentServlet")
public class NewDocumentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String picture = request.getParameter("image");
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String subject = request.getParameter("subject");
		int year = Integer.parseInt(request.getParameter("year"));
		String file = request.getParameter("file");
		Document d = new Document();
		HttpSession hs=request.getSession();
		d.setUserName((String)hs.getAttribute("tId"));
		d.setImage(picture);
		d.setTitle(title);
		d.setAuthor(author);
		d.setSubject(subject);
		d.setYear(year);
		d.setFile(file);
		hs.setAttribute("newdocument", d);
		RequestDispatcher rd = request.getRequestDispatcher("uploaddocumentimage.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
