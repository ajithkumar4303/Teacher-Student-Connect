package com.tsc.controller;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.tsc.bo.RegisterBO;


@WebServlet("/UploadTeacherImageServlet")
@MultipartConfig
public class UploadTeacherImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String save_dir="myfiles";
	String fname=null;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			String fullPath=request.getServletContext().getRealPath("")+File.separator+ save_dir;
			File f=new File(fullPath);
			if(!f.exists()) {
				f.mkdir();
			}
			for(Part part:request.getParts()) {
				fname = extractFile(part);
				part.write(fullPath+File.separator+fname);
			}
			response.setContentType("text/html");
			RegisterBO rbo=new RegisterBO();
			HttpSession hs=request.getSession();
			
			boolean status = rbo.addTeacherImage(fname,(String)hs.getAttribute("imageUserId"));
			if(status==true) {
				response.getWriter().println("<div align='center'><h1>Teacher Photo Uploaded Successfully</h1><br><br>");
				response.getWriter().println("<a href='login.jsp'>Home Page</a></div>");
				
			}else {
				response.getWriter().println("<div align='center'><h1>Photo Upload Failed</h1><br><br>");
				response.getWriter().println("<a href='uploadteacherimage.jsp'>Go Back</a></div>");
			}
			
			
	}
	private String extractFile(Part part) {
		String conDisp = part.getHeader("content-disposition");	
		String[] items = conDisp.split(";");
		for(String item:items) {
			if(item.trim().startsWith("filename")) {
				return item.substring(item.indexOf("=")+2, item.length()-1);
			}
		}
		return "";
	}
	
	

}
	


