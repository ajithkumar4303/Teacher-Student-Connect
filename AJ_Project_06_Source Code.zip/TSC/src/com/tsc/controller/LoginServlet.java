package com.tsc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tsc.bo.RegisterBO;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String db=request.getParameter("category");
		RegisterBO rbo=new RegisterBO();
		boolean status=rbo.validateUser(username,password,db);
		if(status==true) {
			HttpSession hs=request.getSession();
			RequestDispatcher rd=request.getRequestDispatcher("homepage.jsp");
			hs.setAttribute("tId", username);			
			rd.forward(request, response);
		}else {
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			request.setAttribute("msg", "Invalid Username and Password");
			rd.forward(request, response);
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
