package com.tsc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tsc.bo.RegisterBO;
import com.tsc.model.Teacher;

@WebServlet("/TeacherDetailsServlet")
public class TeacherDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("teacherId");

		RegisterBO rbo = new RegisterBO();
		Teacher t = rbo.getTeacherById(id);
		if (t != null) {
			RequestDispatcher rd=request.getRequestDispatcher("displayteacherbyid.jsp");
			request.setAttribute("teacher", t);
			rd.forward(request, response);
		} else {
			System.out.println("Teacher ID not found");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
