package com.tsc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tsc.bo.RegisterBO;
import com.tsc.model.Student;

@WebServlet("/StudentDetailsServlet")
public class StudentDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("studentId");

		RegisterBO rbo = new RegisterBO();
		Student s=rbo.getStudentById(id);
	
		if (s != null) {
			RequestDispatcher rd=request.getRequestDispatcher("displaystudentbyid.jsp");
			request.setAttribute("student", s);
			rd.forward(request, response);
		} else {
			System.out.println("Student ID not found");
		}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
