package com.tsc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tsc.dao.RegisterDAO;
import com.tsc.model.Student;
@WebServlet("/StudentRegistrationServlet")
public class StudentRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname=request.getParameter("firstname");
		String lname=request.getParameter("lastname");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		long contactNumber=Long.parseLong(request.getParameter("contact"));
		String specialization=request.getParameter("specialization");
		int batch=Integer.parseInt(request.getParameter("batch"));
		int docUpload=Integer.parseInt(request.getParameter("documents"));
		String userId=request.getParameter("userid");
		String password=request.getParameter("password");
		String picture=request.getParameter("picture");
	
		Student s=new Student();
		s.setStudentFirstName(fname);
		s.setStudentLastName(lname);
		s.setStudentAge(age);
		s.setStudentGender(gender);
		s.setStudentContactNumber(contactNumber);
		s.setStudentSpecialization(specialization);
		s.setStudentBatch(batch);
		s.setStudentDocUpload(docUpload);
		s.setStudentUserId(userId);
		s.setStudentPassword(password);
		s.setStudentPicture(picture);
		HttpSession hs=request.getSession();
		
		RegisterDAO dao=new RegisterDAO();
		int status=dao.registerStudent(s);
		if(status!=0)
		{
			RequestDispatcher rd=request.getRequestDispatcher("uploadstudentimage.jsp");
			hs.setAttribute("imageUserId", userId);
			rd.forward(request, response);
		
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("registerfailure.jsp");
			request.setAttribute("uId",userId);
			rd.forward(request, response);
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
	}

}
