package com.tsc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tsc.dao.RegisterDAO;
import com.tsc.model.Teacher;


@WebServlet("/TeacherRegistrationServlet")
public class TeacherRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname=request.getParameter("firstname");
		String lname=request.getParameter("lastname");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		long contactNumber=Long.parseLong(request.getParameter("contact"));
		String specialization=request.getParameter("specialization");
		int student=Integer.parseInt(request.getParameter("students"));
		int pLeave=Integer.parseInt(request.getParameter("plannedleave"));
		String userId=request.getParameter("userid");
		String password=request.getParameter("password");
		String picture=request.getParameter("picture");
		
		Teacher t=new Teacher();
		t.setTeacherFirstName(fname);
		t.setTeacherLastName(lname);
		t.setTeacherAge(age);
		t.setTeacherGender(gender);
		t.setTeacherContactNumber(contactNumber);
		t.setTeacherSpecialization(specialization);
		t.setTeacherNoOfStudents(student);
		t.setTeacherPlannedLeave(pLeave);
		t.setTeacherUserId(userId);
		t.setTeacherPassword(password);
		t.setTeacherPicture(picture);
		HttpSession hs=request.getSession();
		
		RegisterDAO dao=new RegisterDAO();
		int status=dao.registerTeacher(t);
		if(status!=0)
		{
			RequestDispatcher rd=request.getRequestDispatcher("uploadteacherimage.jsp");
			hs.setAttribute("imageUserId", userId);
			rd.forward(request, response);
		
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("registerfailure.jsp");
			request.setAttribute("uId",userId);
			rd.forward(request, response);
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
