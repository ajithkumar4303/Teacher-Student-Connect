package com.tsc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tsc.dao.RegisterDAO;
import com.tsc.model.Schedule;


@WebServlet("/ScheduleServlet")
public class ScheduleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String date=request.getParameter("date");
		String time=request.getParameter("time");
		int batch=Integer.parseInt(request.getParameter("batch"));
		String subject=request.getParameter("subject");
		String notes=request.getParameter("notes");
		HttpSession hs=request.getSession();
		Schedule ss=new Schedule();
		ss.setTeacherId((String)hs.getAttribute("tId"));
		ss.setDate(date);
		ss.setTime(time);
		ss.setBatch(batch);
		ss.setSubject(subject);
		ss.setNotes(notes);
		RegisterDAO dao=new RegisterDAO();
		int status=dao.registerSchedule(ss);
		hs.setAttribute("schedule", ss);
		if(status!=0)
		{
			RequestDispatcher rd=request.getRequestDispatcher("DisplayInfoServlet");
			rd.forward(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("TeacherInfoServlet");
			rd.forward(request, response);
		}
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
