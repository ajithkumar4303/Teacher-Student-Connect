package com.tsc.bo;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import com.tsc.dao.RegisterDAO;
import com.tsc.model.Document;
import com.tsc.model.Schedule;
import com.tsc.model.Student;
import com.tsc.model.Teacher;

public class RegisterBO {
	public static final String file_path="C:\\Users\\760872\\eclipse-workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\TSC\\myfiles\\";
	RegisterDAO rdao=new RegisterDAO();
	public boolean validateUser(String username, String password, String db) {
		boolean result=false;
		if(db.equalsIgnoreCase("Teacher")) {
			result = rdao.teacherLoginValidate(username,password);
		}else {
			result = rdao.studentLoginValidate(username,password);
		}
		return result;
	}
	
	public boolean addTeacherImage(String parameter,String tId) throws IOException {
		FileInputStream fis=new FileInputStream(file_path+parameter);
		return rdao.uploadTeacherImage(fis,file_path+parameter,tId);
	}
	
	public boolean addStudentImage(String parameter,String uId) throws IOException {
		FileInputStream fis=new FileInputStream(file_path+parameter);
		return rdao.uploadStudentImage(fis,file_path+parameter,uId);
	}
	
	public boolean addDocumentImage(String parameter,String tId, Document d1) throws IOException {
		FileInputStream fis=new FileInputStream(file_path+parameter);
		return rdao.uploadDocumentImage(fis,file_path+parameter,tId,d1);
	}

	public Teacher getTeacherById(String id) {
		
		return rdao.getTeacherById(id);
	}

	public Student getStudentById(String id) {
		
		return rdao.getStudentById(id);
	}

	public List<Schedule> getTeacherScheduleById(String teacherId) {
		
		return rdao.getTeacherScheduleById(teacherId);
	}

	public Document getDocumentById(String name ) {
		
		return rdao.getDocumentById(name);
	}

	
	
	

}
