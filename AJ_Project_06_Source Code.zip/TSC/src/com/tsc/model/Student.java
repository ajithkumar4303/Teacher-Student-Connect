package com.tsc.model;

public class Student {
	private String studentFirstName;
	private String studentLastName;
	private int studentAge;
	private String studentGender;
	private long studentContactNumber;
	private String studentSpecialization;
	private int studentBatch;
	private int studentDocUpload;
	private String studentUserId;
	private String studentPassword;
	private String studentPicture;
	private String studentPictureFileName;
	public String getStudentFirstName() {
		return studentFirstName;
	}
	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}
	public String getStudentLastName() {
		return studentLastName;
	}
	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}
	public int getStudentAge() {
		return studentAge;
	}
	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}
	public String getStudentGender() {
		return studentGender;
	}
	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}
	
	public String getStudentSpecialization() {
		return studentSpecialization;
	}
	public void setStudentSpecialization(String studentSpecialization) {
		this.studentSpecialization = studentSpecialization;
	}
	public int getStudentBatch() {
		return studentBatch;
	}
	public void setStudentBatch(int studentBatch) {
		this.studentBatch = studentBatch;
	}
	public int getStudentDocUpload() {
		return studentDocUpload;
	}
	public void setStudentDocUpload(int studentDocUpload) {
		this.studentDocUpload = studentDocUpload;
	}
	public String getStudentUserId() {
		return studentUserId;
	}
	public void setStudentUserId(String studentUserId) {
		this.studentUserId = studentUserId;
	}
	public String getStudentPassword() {
		return studentPassword;
	}
	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}
	public String getStudentPicture() {
		return studentPicture;
	}
	public void setStudentPicture(String studentPicture) {
		this.studentPicture = studentPicture;
	}
	public long getStudentContactNumber() {
		return studentContactNumber;
	}
	public void setStudentContactNumber(long studentContactNumber) {
		this.studentContactNumber = studentContactNumber;
	}
	public String getStudentPictureFileName() {
		return studentPictureFileName;
	}
	public void setStudentPictureFileName(String studentPictureFileName) {
		this.studentPictureFileName = studentPictureFileName;
	}
	
}
