package com.tsc.model;

public class Teacher {
	private String teacherFirstName;
	private String teacherLastName;
	private int teacherAge;
	private String teacherGender;
	private long teacherContactNumber;
	private String teacherSpecialization;
	private int teacherNoOfStudents;
	private int teacherPlannedLeave;
	private String teacherUserId;
	private String teacherPassword;
	private String teacherPicture;
	private String teacherPictureFileName;
	public String getTeacherFirstName() {
		return teacherFirstName;
	}
	public void setTeacherFirstName(String teacherFirstName) {
		this.teacherFirstName = teacherFirstName;
	}
	public String getTeacherLastName() {
		return teacherLastName;
	}
	public void setTeacherLastName(String teacherLastName) {
		this.teacherLastName = teacherLastName;
	}
	public int getTeacherAge() {
		return teacherAge;
	}
	public void setTeacherAge(int teacherAge) {
		this.teacherAge = teacherAge;
	}
	public String getTeacherGender() {
		return teacherGender;
	}
	public void setTeacherGender(String teacherGender) {
		this.teacherGender = teacherGender;
	}
	
	public String getTeacherSpecialization() {
		return teacherSpecialization;
	}
	public void setTeacherSpecialization(String teacherSpecialization) {
		this.teacherSpecialization = teacherSpecialization;
	}
	public int getTeacherNoOfStudents() {
		return teacherNoOfStudents;
	}
	public void setTeacherNoOfStudents(int teacherNoOfStudents) {
		this.teacherNoOfStudents = teacherNoOfStudents;
	}
	public int getTeacherPlannedLeave() {
		return teacherPlannedLeave;
	}
	public void setTeacherPlannedLeave(int teacherPlannedLeave) {
		this.teacherPlannedLeave = teacherPlannedLeave;
	}
	public String getTeacherUserId() {
		return teacherUserId;
	}
	public void setTeacherUserId(String teacherUserId) {
		this.teacherUserId = teacherUserId;
	}
	public String getTeacherPassword() {
		return teacherPassword;
	}
	public void setTeacherPassword(String teacherPassword) {
		this.teacherPassword = teacherPassword;
	}
	public String getTeacherPicture() {
		return teacherPicture;
	}
	public void setTeacherPicture(String teacherPicture) {
		this.teacherPicture = teacherPicture;
	}
	public long getTeacherContactNumber() {
		return teacherContactNumber;
	}
	public void setTeacherContactNumber(long teacherContactNumber) {
		this.teacherContactNumber = teacherContactNumber;
	}
	public String getTeacherPictureFileName() {
		return teacherPictureFileName;
	}
	public void setTeacherPictureFileName(String teacherPictureFileName) {
		this.teacherPictureFileName = teacherPictureFileName;
	}
	
	
}
