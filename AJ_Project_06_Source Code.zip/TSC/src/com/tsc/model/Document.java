package com.tsc.model;

public class Document {
private String userName;
private String image;
private String title;
private String author;
private String subject;
private int year;
private String file;
private String fileName;
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public String getFile() {
	return file;
}
public void setFile(String file) {
	this.file = file;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}


}
