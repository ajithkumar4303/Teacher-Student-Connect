package com.tsc.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.print.attribute.standard.RequestingUserName;

import com.tsc.model.Document;
import com.tsc.model.Schedule;
import com.tsc.model.Student;
import com.tsc.model.Teacher;

public class RegisterDAO {
	public static final String path="C:\\Users\\760872\\eclipse-workspace\\TSC\\WebContent\\uploads\\";
	public static final String teacherImagePath="C:\\Users\\760872\\eclipse-workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\TSC\\myfiles\\";
	
	String url = "jdbc:mysql://localhost:3306/tscdb";
	String username = "root";
	String password = "root";
	int result=0;
	
	
		
	public int registerStudent(Student s1)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, s1.getStudentFirstName());
			pstmt.setString(2, s1.getStudentLastName());
			pstmt.setInt(3, s1.getStudentAge());
			pstmt.setString(4, s1.getStudentGender());
			pstmt.setLong(5, s1.getStudentContactNumber());
			pstmt.setString(6, s1.getStudentSpecialization());
			pstmt.setInt(7, s1.getStudentBatch());
			pstmt.setInt(8, s1.getStudentDocUpload());
			pstmt.setString(9, s1.getStudentUserId());
			pstmt.setString(10, s1.getStudentPassword());
			pstmt.setString(11, s1.getStudentPicture());
			pstmt.setString(12, null);
			result=pstmt.executeUpdate();
			
		
		} catch (ClassNotFoundException | SQLException e) {
			result=0;
			e.printStackTrace();
		}
		return result;
		
	}
	
	
	public int registerTeacher(Teacher t1) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("insert into teacher values(?,?,?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, t1.getTeacherFirstName());
			pstmt.setString(2, t1.getTeacherLastName());
			pstmt.setInt(3, t1.getTeacherAge());
			pstmt.setString(4, t1.getTeacherGender());
			pstmt.setLong(5, t1.getTeacherContactNumber());
			pstmt.setString(6, t1.getTeacherSpecialization());
			pstmt.setInt(7, t1.getTeacherNoOfStudents() );
			pstmt.setInt(8, t1.getTeacherPlannedLeave());
			pstmt.setString(9, t1.getTeacherUserId());
			pstmt.setString(10, t1.getTeacherPassword());
			pstmt.setString(11, t1.getTeacherPicture());
			pstmt.setString(12, null);
			result=pstmt.executeUpdate();
			
		} catch (ClassNotFoundException | SQLException e) {
			result=0;
			e.printStackTrace();
		}
		return result;
		
	}
	
	
	public ArrayList<Document> displayAllDocuments() throws IOException
	{
		ArrayList<Document> dlist=new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select * from document");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				Document d= new Document();
				d.setImage(rs.getString(1));
				d.setTitle(rs.getString(2));
				d.setAuthor(rs.getString(3));
				d.setSubject(rs.getString(4));
				d.setYear(rs.getInt(5));
				d.setFileName(rs.getString(8));
				Blob b=rs.getBlob(6);
				
				int index = rs.getString(8).lastIndexOf("\\");
				String fileFullPathName=path+rs.getString(8).substring(index+1, rs.getString(8).length());
				
				File image = new File(fileFullPathName);
			    FileOutputStream fos = new FileOutputStream(image);
			    byte[] buffer = new byte[1];
			    InputStream is = b.getBinaryStream();
				
				 while (is.read(buffer) > 0) {
				        fos.write(buffer);
				      }
				 fos.close();
				 dlist.add(d);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return dlist;
		
	}
	
	
	public ArrayList<Teacher> displayAllTeachers() throws IOException
	{
	
		ArrayList<Teacher> tlist=new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select Picture,First_name,Specialization,No_Of_Students,Planned_Leaves,picturefilename,userid from teacher");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				Teacher t=new Teacher();
				Blob b=rs.getBlob(1);
				t.setTeacherFirstName(rs.getString(2));
				t.setTeacherSpecialization(rs.getString(3));
				t.setTeacherNoOfStudents(rs.getInt(4));
				t.setTeacherPlannedLeave(rs.getInt(5));
				t.setTeacherPictureFileName(rs.getString(6));
				t.setTeacherUserId(rs.getString(7));
				int index = rs.getString(6).lastIndexOf("\\");
				String fileFullPathName=path+rs.getString(6).substring(index+1, rs.getString(6).length());
				
				File image = new File(fileFullPathName);
			    FileOutputStream fos = new FileOutputStream(image);
			    byte[] buffer = new byte[1];
			    InputStream is = b.getBinaryStream();
				
				 while (is.read(buffer) > 0) {
				        fos.write(buffer);
				      }
				 fos.close();
				tlist.add(t);
				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return tlist;
		
	}
	
	
	
	public ArrayList<Student> displayAllStudents() throws IOException
	{
	
		ArrayList<Student> slist=new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select Picture,First_name,Specialization,Batch,No_Of_Documents_Uploaded,picturefilename,userId from student");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				Student s=new Student();
				Blob b=rs.getBlob(1);
				s.setStudentFirstName(rs.getString(2));
				s.setStudentSpecialization(rs.getString(3));
				s.setStudentBatch(rs.getInt(4));
				s.setStudentDocUpload(rs.getInt(5));
				s.setStudentPictureFileName(rs.getString(6));
				s.setStudentUserId(rs.getString(7));
				int index = rs.getString(6).lastIndexOf("\\");
				String fileFullPathName=path+rs.getString(6).substring(index+1, rs.getString(6).length());
				
				File image = new File(fileFullPathName);
			    FileOutputStream fos = new FileOutputStream(image);
			    byte[] buffer = new byte[1];
			    InputStream is = b.getBinaryStream();
				
				 while (is.read(buffer) > 0) {
				        fos.write(buffer);
				      }
				 fos.close();
				slist.add(s);
				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return slist;
		
	}


	
	
	


	public boolean teacherLoginValidate(String username2, String password2) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select * from teacher where userid=? and password=?");
			pstmt.setString(1, username2);
			pstmt.setString(2, password2);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				return true;				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return false;
	}


	public boolean studentLoginValidate(String username2, String password2) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select * from student where userid=? and password=?");
			pstmt.setString(1, username2);
			pstmt.setString(2, password2);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				return true;				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return false;
	}


	
	
	
	
	
	

	public boolean uploadTeacherImage(FileInputStream fis,String file,String tId) throws IOException {
		try {
					
			File f=new File(file);
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("update teacher set Picture=?,picturefilename=? where userId=?");
			pstmt.setBinaryStream(1, fis,f.length());
			pstmt.setString(2, file);
			pstmt.setString(3, tId);
			int result = pstmt.executeUpdate();
			if(result!=0)
			{
				return true;				
			}
			fis.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fis.close();
		}		
		return false;
	}
	
	public boolean uploadStudentImage(FileInputStream fis, String file1, String uId) throws IOException {
		try {
			
			File f=new File(file1);
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("update student set Picture=?,picturefilename=? where userId=?");
			pstmt.setBinaryStream(1, fis,f.length());
			pstmt.setString(2, file1);
			pstmt.setString(3, uId);
			int result = pstmt.executeUpdate();
			if(result!=0)
			{
				return true;				
			}
			fis.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fis.close();
		}		
		return false;
	}


	public boolean uploadDocumentImage(FileInputStream fis, String doc, String tId, Document d1) throws IOException {
		
		try {
			d1.setFileName(doc);
			File f=new File(doc);
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("insert into document values(?,?,?,?,?,?,?,?)");
			pstmt.setString(1, d1.getImage());
			pstmt.setString(2, d1.getTitle());
			pstmt.setString(3, d1.getAuthor());
			pstmt.setString(4, d1.getSubject());
			pstmt.setInt(5, d1.getYear());
			pstmt.setBinaryStream(6, fis, f.length());
			pstmt.setString(7, d1.getUserName());
			pstmt.setString(8, d1.getFileName());
			result=pstmt.executeUpdate();
			if(result!=0) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fis.close();
		}	
		return false;
	}


	public Teacher getTeacherById(String id) {
		Teacher t=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select * from teacher where userid=?");
			pstmt.setString(1, id);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				t=new Teacher();
				t.setTeacherFirstName(rs.getString(1));
				t.setTeacherLastName(rs.getString(2));
				t.setTeacherAge(rs.getInt(3));
				t.setTeacherGender(rs.getString(4));
				t.setTeacherContactNumber(rs.getLong(5));
				t.setTeacherSpecialization(rs.getString(6));
				t.setTeacherNoOfStudents(rs.getInt(7));
				t.setTeacherPlannedLeave(rs.getInt(8));
				t.setTeacherUserId(rs.getString(9));
				t.setTeacherPictureFileName(rs.getString(12));
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return t;
	}


	public Student getStudentById(String id) {
		Student s=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select * from student where userid=?");
			pstmt.setString(1, id);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				s=new Student();
				s.setStudentFirstName(rs.getString(1));
				s.setStudentLastName(rs.getString(2));
				s.setStudentAge(rs.getInt(3));
				s.setStudentGender(rs.getString(4));
				s.setStudentContactNumber(rs.getLong(5));
				s.setStudentSpecialization(rs.getString(6));
				s.setStudentBatch(rs.getInt(7));
				s.setStudentDocUpload(rs.getInt(8));
				s.setStudentUserId(rs.getString(9));
				s.setStudentPictureFileName(rs.getString(12));				
				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return s;
	}


	public int registerSchedule(Schedule ss) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("insert into periodinfo values(?,?,?,?,?,?)");
			pstmt.setString(1, ss.getDate());
			pstmt.setString(2, ss.getTime());
			pstmt.setInt(3, ss.getBatch());
			pstmt.setString(4, ss.getSubject());
			pstmt.setString(5, ss.getNotes());
			pstmt.setString(6, ss.getTeacherId());
			result=pstmt.executeUpdate();
			
		} catch (ClassNotFoundException | SQLException e) {
			result=0;
			e.printStackTrace();
		}
		return result;
	}


	public ArrayList<Schedule> displayTeacherSchedule() {
		
		ArrayList<Schedule> sslist=new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select * from periodinfo");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				Schedule ss=new Schedule();
				ss.setDate(rs.getString(1));
				ss.setTime(rs.getString(2));
				ss.setBatch(rs.getInt(3));
				ss.setSubject(rs.getString(4));
				ss.setNotes(rs.getString(5));
				sslist.add(ss);
			
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sslist;
		
	}


	public List<Schedule> getTeacherScheduleById(String teacherId) {
		ArrayList<Schedule> sslist=new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt=con.prepareStatement("select * from periodinfo where teacherid=?");
			pstmt.setString(1, teacherId);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				Schedule ss=new Schedule();
				ss.setTeacherId(rs.getString(6));
				ss.setDate(rs.getString(1));
				ss.setTime(rs.getString(2));
				ss.setBatch(rs.getInt(3));
				ss.setSubject(rs.getString(4));
				ss.setNotes(rs.getString(5));
				sslist.add(ss);
			
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sslist;
	}


	public Document getDocumentById(String name) {
			Document d=null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection(url, username, password);
				PreparedStatement pstmt=con.prepareStatement("select * from document where username=?");
				pstmt.setString(1, name);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next())
				{
					d=new Document();
					d.setTitle(rs.getString(1));
					d.setAuthor(rs.getString(2));
					d.setSubject(rs.getString(3));
					d.setYear(rs.getInt(4));
					d.setFile(rs.getString(5));	
				}
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			return d;
	}
	
}
